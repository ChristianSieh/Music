
#ifndef WAVE_HEADER_H
#define WAVE_HEADER_H

void write_wave_header(int fd, int nsamples);

#endif
